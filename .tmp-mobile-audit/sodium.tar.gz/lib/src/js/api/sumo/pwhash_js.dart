import 'dart:convert';
import 'dart:js_interop';
import 'dart:typed_data';

import 'package:meta/meta.dart';

import '../../../api/secure_key.dart';
import '../../../api/string_x.dart';
import '../../../api/sumo/pwhash.dart';
import '../../bindings/int_helpers_x.dart';
import '../../bindings/js_error.dart';
import '../../bindings/sodium.js.dart';
import '../secure_key_js.dart';

/// @nodoc
@visibleForTesting
extension CrypoPwhashAlgorithmJS on CryptoPwhashAlgorithm {
  /// @nodoc
  int getValue(LibSodiumJS sodium) {
    switch (this) {
      case CryptoPwhashAlgorithm.defaultAlg:
        return sodium.crypto_pwhash_ALG_DEFAULT;
      case CryptoPwhashAlgorithm.argon2i13:
        return sodium.crypto_pwhash_ALG_ARGON2I13;
      case CryptoPwhashAlgorithm.argon2id13:
        return sodium.crypto_pwhash_ALG_ARGON2ID13;
    }
  }
}

@internal
// ignore: public_member_api_docs false positive
class PwhashJS(final LibSodiumJS sodium)
    with PwHashValidations
    implements Pwhash {
  @visibleForTesting
  static const memLimitMaxFallback = 4398046510080;

  @override
  int get bytesMin => sodium.crypto_pwhash_BYTES_MIN;
  @override
  int get bytesMax => sodium.crypto_pwhash_BYTES_MAX.safeUint32();

  @override
  int get memLimitMin => sodium.crypto_pwhash_MEMLIMIT_MIN;
  @override
  int get memLimitInteractive => sodium.crypto_pwhash_MEMLIMIT_INTERACTIVE;
  @override
  int get memLimitModerate => sodium.crypto_pwhash_MEMLIMIT_MODERATE;
  @override
  int get memLimitSensitive => sodium.crypto_pwhash_MEMLIMIT_SENSITIVE;
  @override
  int get memLimitMax =>
      sodium.crypto_pwhash_MEMLIMIT_MAX.safeUnsigned(memLimitMaxFallback);

  @override
  int get opsLimitMin => sodium.crypto_pwhash_OPSLIMIT_MIN;
  @override
  int get opsLimitInteractive => sodium.crypto_pwhash_OPSLIMIT_INTERACTIVE;
  @override
  int get opsLimitModerate => sodium.crypto_pwhash_OPSLIMIT_MODERATE;
  @override
  int get opsLimitSensitive => sodium.crypto_pwhash_OPSLIMIT_SENSITIVE;
  @override
  int get opsLimitMax => sodium.crypto_pwhash_OPSLIMIT_MAX.safeUint32();

  @override
  int get passwdMin => sodium.crypto_pwhash_PASSWD_MIN;
  @override
  int get passwdMax => sodium.crypto_pwhash_PASSWD_MAX.safeUint32();

  @override
  int get saltBytes => sodium.crypto_pwhash_SALTBYTES;

  @override
  int get strBytes => sodium.crypto_pwhash_STRBYTES;

  @Deprecated('Use callStr or callRaw instead')
  @override
  SecureKey call({
    required int outLen,
    required Int8List password,
    required Uint8List salt,
    required int opsLimit,
    required int memLimit,
    CryptoPwhashAlgorithm alg = CryptoPwhashAlgorithm.defaultAlg,
  }) => callRaw(
    outLen: outLen,
    password: password,
    salt: salt,
    opsLimit: opsLimit,
    memLimit: memLimit,
    alg: alg,
  );

  @override
  SecureKey callStr({
    required int outLen,
    required String password,
    Encoding passwordEncoding = utf8,
    required Uint8List salt,
    required int opsLimit,
    required int memLimit,
    CryptoPwhashAlgorithm alg = CryptoPwhashAlgorithm.defaultAlg,
  }) => callRaw(
    outLen: outLen,
    password: password.toCharArray(encoding: passwordEncoding),
    salt: salt,
    opsLimit: opsLimit,
    memLimit: memLimit,
    alg: alg,
  );

  @override
  SecureKey callRaw({
    required int outLen,
    required Int8List password,
    required Uint8List salt,
    required int opsLimit,
    required int memLimit,
    CryptoPwhashAlgorithm alg = CryptoPwhashAlgorithm.defaultAlg,
  }) {
    validateOutLen(outLen);
    validatePassword(password);
    validateSalt(salt);
    validateOpsLimit(opsLimit);
    validateMemLimit(memLimit);

    final result = jsErrorWrap(
      () => sodium.crypto_pwhash(
        outLen,
        password.unsignedView().toJS,
        salt.toJS,
        opsLimit,
        memLimit,
        alg.getValue(sodium),
      ),
    );
    return SecureKeyJS(sodium, result);
  }

  @override
  String str({
    required String password,
    required int opsLimit,
    required int memLimit,
    Encoding passwordEncoding = utf8,
  }) {
    final passwordChars = password.toCharArray(encoding: passwordEncoding);
    validatePassword(passwordChars);
    validateOpsLimit(opsLimit);
    validateMemLimit(memLimit);

    final result = jsErrorWrap(
      () => sodium.crypto_pwhash_str(
        passwordChars.unsignedView().toJS,
        opsLimit,
        memLimit,
      ),
    );
    return result;
  }

  @override
  bool strVerify({
    required String passwordHash,
    required String password,
    Encoding passwordEncoding = utf8,
  }) {
    final passwordChars = password.toCharArray(encoding: passwordEncoding);
    validatePasswordHashStr(passwordHash);
    validatePassword(passwordChars);

    return jsErrorWrap(
      () => sodium.crypto_pwhash_str_verify(
        passwordHash,
        passwordChars.unsignedView().toJS,
      ),
    );
  }

  @override
  bool strNeedsRehash({
    required String passwordHash,
    required int opsLimit,
    required int memLimit,
  }) {
    validatePasswordHashStr(passwordHash);
    validateOpsLimit(opsLimit);
    validateMemLimit(memLimit);

    return jsErrorWrap(
      () => sodium.crypto_pwhash_str_needs_rehash(
        passwordHash,
        opsLimit,
        memLimit,
      ),
    );
  }
}
