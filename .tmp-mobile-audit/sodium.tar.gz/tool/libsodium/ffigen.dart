import 'dart:ffi';
import 'dart:io';

import 'package:analyzer/dart/analysis/analysis_context_collection.dart';
import 'package:analyzer/dart/analysis/results.dart';
import 'package:analyzer/dart/element/element.dart';
import 'package:analyzer/dart/element/type.dart';
import 'package:code_builder/code_builder.dart' as cb;
import 'package:collection/collection.dart';
import 'package:dart_style/dart_style.dart';
import 'package:dart_test_tools/code_gen.dart';
import 'package:ffigen/ffigen.dart';
import 'package:sodium/src/hooks/constants.dart';
import 'package:source_gen/source_gen.dart';

void main() async {
  final bindingsUri = await _ffigen();
  await _generateWrapper(bindingsUri);
}

final _pragmaInline = const cb.Reference('pragma')
    .call([cb.literalString('vm:prefer-inline')]);

const _ffiNativeChecker = TypeChecker.typeNamed(Native, inSdk: true);
bool _isFfiNativeAnnotation(ElementAnnotation annotation) {
  final element = annotation.element?.enclosingElement;
  return element != null && _ffiNativeChecker.isExactly(element);
}

Future<Uri> _ffigen() async {
  final headersLocationFile = File.fromUri(
    HookConstants.libsodiumHeadersLocation,
  );
  if (!headersLocationFile.existsSync()) {
    throw Exception(
      'Libsodium headers location file missing at ${headersLocationFile.uri}. '
      'You must set ${HookConstants.exportHeadersEnvVarName} to 1 to '
      'generate the location.',
    );
  }

  final locationUri = Uri.parse(await headersLocationFile.readAsString());

  final packageRoot = Platform.script.resolve('../../');
  final outUri = packageRoot.resolve('lib/src/ffi/bindings/libsodium.ffi.dart');
  await FfiGenerator(
    output: Output(
      dart: DartOutput(path: outUri),
      style: const NativeExternalBindings(assetId: 'package:sodium/libsodium'),
    ),
    input: Input(
      entryPoints: [locationUri.resolve('sodium.h')],
      compilerOptions: [
        if (Platform.isLinux) '-I/usr/lib/clang/22/include/',
        if (Platform.isMacOS) '-I$macSdkPath/usr/include/',
      ],
      ignoreSourceErrors: true,
    ),
    visitors: [
      Visitor(
        macroConstant: (n) => n.isIncluded = _matchesLibsodium(n),
        global: (n) => n.isIncluded = _matchesLibsodium(n),
        enumClass: (n) => n.isIncluded = _matchesLibsodium(n),
        struct: (n) => n.isIncluded = _matchesLibsodium(n),
        union: (n) => n.isIncluded = _matchesLibsodium(n),
        func: (n) => n.isIncluded = _matchesLibsodium(n),
        typealias: (n) =>
            n.isIncluded = _matchesLibsodium(n) ? .ifUsed : .never,
      ),
    ],
  ).generate();

  // add missing ignore
  final generatedFile = File.fromUri(outUri);
  final generatedContent = generatedFile.readAsStringSync();
  final updatedContent = generatedContent.replaceFirst(
    'unused_import',
    'unused_import, unused_field',
  );
  generatedFile.writeAsStringSync(updatedContent);

  return outUri;
}

bool _matchesLibsodium(NamedNode node) {
  final lowerName = node.originalName.toLowerCase();
  return lowerName.startsWith('sodium') ||
      lowerName.startsWith('crypto') ||
      lowerName.startsWith('randombytes');
}

Future<void> _generateWrapper(Uri bindingsUri) async {
  final filePath = bindingsUri.toFilePath();
  final result = await AnalysisContextCollection(includedPaths: [filePath])
      .contextFor(filePath)
      .currentSession
      .getResolvedLibrary(filePath);
  if (result is! ResolvedLibraryResult) {
    throw Exception('Could not resolve $filePath: $result');
  }

  final buffer = StringBuffer();
  _buildWrapperLibrary(result.element).accept(
    cb.DartEmitter.scoped(useNullSafetySyntax: true, orderDirectives: true),
    buffer,
  );

  final wrapperFile = File.fromUri(
    bindingsUri.resolve(
      bindingsUri.pathSegments.last.replaceFirst('.dart', '.wrapper.dart'),
    ),
  );
  final formatter = DartFormatter(
    languageVersion: DartFormatter.latestLanguageVersion,
  );
  await wrapperFile.writeAsString(
    formatter.format(buffer.toString(), uri: wrapperFile.uri),
  );
}

cb.Library _buildWrapperLibrary(LibraryElement library) => cb.Library(
  (b) => b
    ..ignoreForFile.add('document_ignores')
    ..ignoreForFile.add('prefer_relative_imports')
    ..ignoreForFile.add('public_member_api_docs')
    ..ignoreForFile.add('non_constant_identifier_names')
    ..ignoreForFile.add('unnecessary_type_name_in_constructor')
    ..ignoreForFile.add('use_primary_constructors')
    ..body.add(_buildWrapperClass(library)),
);

cb.Class _buildWrapperClass(LibraryElement library) => cb.Class(
  (b) => b
    ..name = 'LibSodiumFFI'
    ..constructors.add(cb.Constructor((b) => b..constant = true))
    ..methods.add(
      cb.Method(
        (b) => b
          ..name = 'sodium_freePtr'
          ..type = .getter
          ..returns = cb.TypeReference(
            (b) => b
              ..symbol = 'Pointer'
              ..url = 'dart:ffi'
              ..isNullable = true
              ..types.add(
                cb.TypeReference(
                  (b) => b
                    ..symbol = 'NativeFinalizerFunction'
                    ..url = 'dart:ffi',
                ),
              ),
          )
          ..body =
              cb.TypeReference(
                    (b) => b
                      ..symbol = 'Native'
                      ..url = 'dart:ffi',
                  )
                  .property('addressOf')
                  .call([cb.refer('sodium_free', library.uri.toString())])
                  .code,
      ),
    )
    ..methods.addAll(library.topLevelFunctions.map(_buildWrapperMethod)),
);

cb.Method _buildWrapperMethod(TopLevelFunctionElement method) => cb.Method(
  (b) => b
    ..name = method.name
    ..annotations.addAll([
      _pragmaInline,
      ...method.metadata.annotations
          .whereNot(_isFfiNativeAnnotation)
          .map((a) => a.computeConstantValue()!)
          .map(ConstantReader.new)
          .map((c) => c.toExpression()),
    ])
    ..returns = _typeFromDartType(method.returnType)
    ..requiredParameters.addAll(method.formalParameters.map(_buildParameter))
    ..body = cb
        .refer(method.name!, method.library.uri.toString())
        .call(method.formalParameters.map((p) => cb.refer(p.name!)))
        .code,
);

cb.Parameter _buildParameter(FormalParameterElement param) => cb.Parameter(
  (b) => b
    ..name = param.name!
    ..type = _typeFromDartType(param.type),
);

cb.Reference _typeFromDartType(DartType type) => switch (type) {
  VoidType() => cb.TypeReference((b) => b..symbol = 'void'),
  FunctionType() => cb.FunctionType((b) {
    b
      ..returnType = _typeFromDartType(type.returnType)
      ..isNullable = type.nullabilitySuffix != .none;
    for (final param in type.formalParameters) {
      final type = _typeFromDartType(param.type);
      if (param.isRequiredPositional) {
        b.requiredParameters.add(type);
      } else if (param.isOptionalPositional) {
        b.optionalParameters.add(type);
      } else if (param.isRequiredNamed) {
        b.namedRequiredParameters[param.name!] = type;
      } else if (param.isOptionalNamed) {
        b.namedParameters[param.name!] = type;
      }
    }
  }),
  InterfaceType() => cb.TypeReference(
    (b) => b
      ..symbol = type.element.name
      ..url = type.element.library.uri.toString()
      ..isNullable = type.nullabilitySuffix != .none
      ..types.addAll(type.typeArguments.map(_typeFromDartType)),
  ),
  _ => throw UnsupportedError('Unsupported Dart type: $type'),
};
