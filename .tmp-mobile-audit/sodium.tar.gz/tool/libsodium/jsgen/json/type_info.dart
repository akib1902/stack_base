import 'package:meta/meta.dart';

typedef DartTypeDef = ({String name, String type});

@immutable
class const TypeInfo(
  final String dartType, {
  final String? typeDef,
  final bool force = false,
}) {
  DartTypeDef? get dartTypeDef =>
      typeDef != null ? (name: dartType, type: typeDef!) : null;
}
