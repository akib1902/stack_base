/// Flutter integration for Supabase.
library;

export 'package:supabase/supabase.dart';
export 'package:url_launcher/url_launcher.dart' show LaunchMode;

export 'src/flutter_go_true_client_options.dart';
export 'src/local_storage.dart';
export 'src/realtime_lifecycle_options.dart';
export 'src/supabase.dart';
export 'src/supabase_auth.dart' hide SupabaseAuth;
export 'src/supabase_passkey.dart';
