import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'widget_test_stubs.dart';

void main() {
  const supabaseUrl = '';
  const supabaseKey = '';

  setUpAll(() {
    mockAppLink();
  });

  testWidgets('Signing out triggers AuthChangeEvent.signedOut event', (
    tester,
  ) async {
    // Initialize the Supabase singleton
    await Supabase.initialize(
      url: supabaseUrl,
      publishableKey: supabaseKey,
      debug: false,
      authOptions: FlutterAuthClientOptions(
        localStorage: const MockLocalStorage(),
        pkceAsyncStorage: MockAsyncStorage(),
      ),
    );
    Supabase.instance.client.auth.stopAutoRefresh();
    await tester.pumpWidget(const MaterialApp(home: MockWidget()));
    await tester.tap(find.text('Sign out'));
    await tester.pumpAndSettle();
    expect(find.text('You have signed out'), findsOneWidget);
  });
}
